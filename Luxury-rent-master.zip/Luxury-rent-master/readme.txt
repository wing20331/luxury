Почта менеджера
Логин: luxuryrentmanagermsk@gmail.com
Пароль: E4po4mack!@#
Почта сайта
Логин: luxuryrentmsk@gmail.com
Пароль: BogdanGlinko

