const $elem = document.getElementById('block');
const text = $elem.textContent;
console.log(text);