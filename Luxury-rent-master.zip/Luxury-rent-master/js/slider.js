new Swiper('.swiper-conatainer', {
    mousewheel: {
        sensitivity: 1,
    },
    slidesPerView: 2.65,
    speed: 400,
    spaceBetween: 30,

});